Download Google Speech Commands Dataset (v0.02)

https://ai.googleblog.com/2017/08/launching-speech-commands-dataset.html



Expected structure:

data/

&nbsp;├── omar/

&nbsp;├── yes/

&nbsp;├── no/

&nbsp;├── \_background\_noise\_/

